package com.example.group2activity_intentandlistview_android;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class AndroidAdapter extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] androidVersion;
    private final int[] androidImages;

    public AndroidAdapter(Activity context, String[] cityNames, int[] cityImages) {
        super(context, R.layout.list_item_android, cityNames);
        this.context = context;
        this.androidVersion = cityNames;
        this.androidImages = cityImages;
    }


    @NonNull
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.list_item_android,null,true);

        TextView titleText = rowView.findViewById(R.id.androidVersionText);
        ImageView imageView = rowView.findViewById(R.id.androidImage);

        titleText.setText(androidVersion[position]);
        imageView.setImageResource(androidImages[position]);

        return rowView;
    }
}
