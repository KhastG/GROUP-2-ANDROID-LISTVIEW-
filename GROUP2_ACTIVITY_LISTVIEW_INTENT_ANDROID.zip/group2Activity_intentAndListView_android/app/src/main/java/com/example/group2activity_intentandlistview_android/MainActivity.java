package com.example.group2activity_intentandlistview_android;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {
    ListView listView;
    String[] androidVersion = {
            "Android 1.0",
            "Android 1.1",
            "Android Cupcake",
            "Android Donut",
            "Android Eclair",
            "Android Froyo",
            "Android GingerBread",
            "Android HoneyComb",
            "Android Ice Cream Sandwich",
            "Android Jelly Bean",
            "Android KitKat",
            "Android Lollipop",
            "Android Marshmallow",
            "Android Nougat",
            "Android Oreo",
            "Android Pie",
            "Android 10",
            "Android 11",
            "Android 12",
    };

    int[] androidImages = {
            R.drawable.android1,
            R.drawable.android2,
            R.drawable.cupcake,
            R.drawable.donut,
            R.drawable.eclair,
            R.drawable.froyo,
            R.drawable.gingerbread,
            R.drawable.honeycomb,
            R.drawable.icecream,
            R.drawable.jellybean,
            R.drawable.kitkat,
            R.drawable.lollipop,
            R.drawable.marshmallow,
            R.drawable.nougat,
            R.drawable.oreo,
            R.drawable.pie,
            R.drawable.android10,
            R.drawable.android11,
            R.drawable.android12,
    };

    String[] androidKeyFeatures = {
            "Android 1.0, released on September 23, 2008, was the first version of the Android OS, launched with the HTC Dream (T-Mobile G1). Its strongest feature was deep integration with Google services like Gmail, Google Maps, Calendar, and Contacts. This allowed real-time syncing and seamless access to cloud-based tools, giving users a connected and productive experience right from the start—something that set Android apart from other mobile systems at the time.",
            "Android 1.1, which was a small update that came after the first version of Android. It says the update focused on making the system more stable and user-friendly that means it fixed some of the bugs and made things smoother to use. It added helpful features like saving email or message attachments, letting the screen stay on longer during calls , and gave Google Maps more detailed information, like business reviews. It made Android more reliable and polished, which helped prepare it for bigger updates later.",
            "Android Cupcake, released in April 2009, was the first version to use a dessert-themed codename and brought major improvements to the Android platform. Its standout feature was the introduction of the on-screen (virtual) keyboard, which allowed phones without physical keyboards to fully use Android. Cupcake also added video recording and playback, widgets for the home screen, and improved app performance. These additions made Android more modern, user-friendly, and flexible for both manufacturers and users.",
            "Android Donut, released in September 2009, expanded Android’s capabilities and accessibility. Its strongest feature was support for different screen sizes and resolutions, allowing Android to run on a wider variety of devices—paving the way for Android's rapid hardware growth. Donut also added a redesigned Android Market, improved voice search, system-wide text-to-speech, and CDMA network support, making it more versatile for global users and carriers.",
            "Android Eclair, released in October 2009, was a major update that introduced several advanced features for smartphones. Its strongest point was the introduction of Google Maps Navigation, a free, turn-by-turn GPS navigation system that competed directly with expensive standalone GPS devices. Eclair also brought support for multiple Google accounts, improved camera features (like flash and digital zoom), live wallpapers, and a revamped browser with HTML5 support—making Android far more powerful and competitive.",
            "Android Froyo, released in May 2010, focused on speed and performance improvements. Its strongest feature was the introduction of Wi-Fi hotspot and USB tethering, allowing users to share their mobile internet connection with other devices. Froyo also added support for Adobe Flash, improved app launching speed with Just-In-Time (JIT) compilation, and enabled app installations on external storage.",
            "Android Gingerbread, launched in December 2010, brought a cleaner user interface and better performance. Its strongest point was support for NFC (Near Field Communication), which laid the foundation for mobile payments and tap-to-transfer features. Gingerbread also introduced better power management tools and improved gaming performance with enhanced graphics and sensor support.",
            "Android Honeycomb, released in February 2011, was designed specifically for tablets. Its strongest feature was the holographic UI optimized for larger screens, including a new system bar, action bar, and improved multitasking. Though short-lived, Honeycomb introduced design elements that influenced later Android versions",
            "Android Ice Cream Sandwich, released in October 2011, unified the smartphone and tablet interfaces under one OS. Its strongest point was the introduction of the Holo design language, which brought a more modern, consistent look across Android. It also added features like face unlock, data usage controls, and improved multitasking",
            "Android Jelly Bean, released from 2012 to 2013, focused on smoothness and responsiveness. The strongest feature was Project Butter, which made animations and touch responses much smoother, greatly improving the user experience. Jelly Bean also introduced Google Now, expandable notifications, and improved voice search.",
            "Android KitKat, launched in October 2013, aimed at optimizing Android for lower-end devices. Its strongest feature was performance optimization for devices with as little as 512MB RAM, helping Android reach a broader range of hardware. KitKat also introduced immersive mode, a lighter UI, and OK Google voice activation",
            "Android Lollipop, released in November 2014, brought a major visual overhaul with the Material Design language. This was its strongest point—creating a unified, bold, and responsive UI across devices. Lollipop also introduced a new runtime (ART), better notifications, and improved battery management",
            "Android Marshmallow, released in October 2015, focused on refining the user experience. Its strongest feature was Granular App Permissions, allowing users to control what information each app could access. It also introduced Doze Mode for better battery life and native fingerprint support",
            "Android Nougat, released in August 2016, improved multitasking and performance. Its strongest feature was split-screen multitasking, letting users use two apps side by side—a long-requested feature. It also added improved notifications and background data control",
            "Android Oreo, launched in August 2017, focused on speed, security, and stability. Its strongest point was background app optimization, which greatly improved battery life and performance. Oreo also introduced picture-in-picture mode, notification dots, and faster boot times",
            "Android Pie, released in August 2018, introduced a more adaptive and intelligent system. Its strongest feature was adaptive battery and brightness, which used machine learning to optimize power usage based on user behavior. Pie also introduced gesture navigation and digital well being tools",
            "Android 10, released in September 2019, marked a shift to gesture-based navigation and a focus on privacy. Its strongest feature was system-wide dark mode, which improved usability in low-light and helped conserve battery. It also offered better privacy controls and smart replies",
            "Android 11, released in September 2020, streamlined communication and device control. Its strongest point was the conversation management system, which grouped messages in a dedicated notification section and added chat bubbles for messaging apps. It also added better control over media and smart devices",
            "Android 12, launched in October 2021, brought a major visual refresh with Material You, its strongest feature. This allowed users to personalize the UI with dynamic theming based on wallpaper colors. Android 12 also improved privacy with new indicators and a privacy dashboard"};

    Button members;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        members = findViewById(R.id.btnMembers);
        listView = findViewById(R.id.ListView);
        members.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cfcf8c")));

        AndroidAdapter adapter = new AndroidAdapter(this, androidVersion, androidImages);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, AndroidDetailActivity.class);
                intent.putExtra("androidVersion", androidVersion[position]);
                intent.putExtra("androidImage", androidImages[position]);
                intent.putExtra("androidKeyFeatures", androidKeyFeatures[position]);
                startActivity(intent);
            }
        });

        members.setOnClickListener(v->{
            Intent intent = new Intent(this,MembersPane.class);
            startActivity(intent);
            finish();
        });
    }
}