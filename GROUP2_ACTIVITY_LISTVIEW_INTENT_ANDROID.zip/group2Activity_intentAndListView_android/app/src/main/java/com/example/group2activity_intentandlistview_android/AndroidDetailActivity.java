package com.example.group2activity_intentandlistview_android;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AndroidDetailActivity extends AppCompatActivity {

    TextView androidVersionTextView, androidKeyFeaturesTextView;
    ImageView androidImageView;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_detail);

        androidVersionTextView = findViewById(R.id.androidVersionTextView);
        androidKeyFeaturesTextView = findViewById(R.id.androidKeyFeaturesTextView);
        androidImageView = findViewById(R.id.androidImageView);
        backButton = findViewById(R.id.backButton);

        String androidVersion = getIntent().getStringExtra("androidVersion");
        int androidImage = getIntent().getIntExtra("androidImage", 0);
        String keyFeatures = getIntent().getStringExtra("androidKeyFeatures");

        androidVersionTextView.setText(androidVersion);
        androidImageView.setImageResource(androidImage);
        androidKeyFeaturesTextView.setText(keyFeatures);

        backButton.setOnClickListener(v -> finish());
        backButton.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cfcf8c")));
    }
}
