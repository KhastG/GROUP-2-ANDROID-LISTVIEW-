public class AndroidAdapter {
}
